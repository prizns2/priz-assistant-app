@echo off
cd /d "%~dp0"
echo === PRIZ Assistant: work PC agent - install ===

set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY where python >nul 2>nul && set "PY=python"
if not defined PY (
  echo !! Python not found. Install Python 3 from python.org - tick "Add python.exe to PATH" - and run install.bat again.
  pause
  exit /b 1
)
%PY% --version

echo Installing requests, psutil ...
%PY% -m pip install --quiet --disable-pip-version-check requests psutil
if errorlevel 1 (
  echo !! pip failed. Check the internet connection and run again.
  pause
  exit /b 1
)

%PY% "%~dp0setup_pc.py"
if errorlevel 1 (
  pause
  exit /b 1
)
echo.
echo Done. Load the extension into the work Brave once - see README.md.
pause

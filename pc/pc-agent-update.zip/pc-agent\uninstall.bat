@echo off
cd /d "%~dp0"
echo === PRIZ Assistant: work PC agent - uninstall ===

set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY where python >nul 2>nul && set "PY=python"
if not defined PY (
  echo !! Python not found.
  pause
  exit /b 1
)
%PY% "%~dp0setup_pc.py" --uninstall
pause
